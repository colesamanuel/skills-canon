# Catálogo de Hallazgos — Odoo Invoice Auditor

Referencia completa de los 15 hallazgos tipificados. Cada uno tiene: código, severidad, criterio de detección, causa probable y acción recomendada.

**Este skill detecta y reporta. No corrige.** Las acciones son para ejecución manual del usuario en UI de Odoo o mediante procesos explícitos fuera de este skill.

## Severidades

| Símbolo | Nivel | Criterio |
|---|---|---|
| 🔴 | Crítico | Impacto fiscal, contable o legal inmediato. Resolver antes de próximo cierre. |
| 🟠 | Alto | Riesgo material. Resolver en el trimestre. |
| 🟡 | Medio | Higiene de datos. Resolver según disponibilidad. |
| 🟢 | Bajo / Observación | No requiere acción inmediata, documentar. |

---

## H0 — Inconsistencia nombre comercial vs razón social 🟢

**Criterio:** Diferencia entre marca conocida y `res.company.name` en Odoo (ej: "Kermatek" vs "KERMATEC DOSIMETRIC SA").

**Causa probable:** Error de digitación al crear la compañía, o razón social real distinta de la marca comercial.

**Acción:** Verificar contra cédula jurídica física. Si el Registro tiene un nombre, ese es el único válido para facturación electrónica ante Hacienda.

---

## H1 — Facturas sin fecha de emisión 🟡

**Criterio:** `invoice_date IS NULL`.

**Causa probable:** Facturas canceladas antes de postear. Casos `draft` o `cancel` son aceptables; si hay `posted` sin fecha, es anomalía grave (escalar a 🔴).

**Acción:** Revisar si son canceladas legítimas. Si alguna está `posted`, investigar origen y corregir manualmente.

---

## H2 — Documentos con número placeholder 🟡

**Criterio:** `name` en ("(sin número)", "/", "") y `state != 'cancel'`.

**Causa probable:** Borradores sin postear, o error de numeración.

**Acción:** Postear para asignar consecutivo, o descartar si ya no es válida.

---

## H3 — Aritmética inconsistente 🔴

**Criterio:** `|amount_untaxed + amount_tax − amount_total| > 0.01`.

**Causa probable:** Corrupción de datos, bug de redondeo, o manipulación directa en base de datos.

**Acción:** Investigar individualmente cada caso. Si hay corrupción sistemática, considerar backup/restore. Notificar a Odoo support si persiste.

---

## H4 — Facturas posted con IVA=0 masivo 🟠

**Criterio:** `state='posted'`, `move_type='out_invoice'`, `amount_tax=0`, y proporción sobre el total facturado es alta (>30%).

**Causa probable en Costa Rica:**
- Servicios exentos (dosimetría personal puede calificar como servicio técnico exento bajo ciertas condiciones).
- Clientes con autorización de compra exenta (CCSS, universidades públicas, instituciones autónomas con régimen especial).
- Exportación de servicios (tarifa 0%).
- Error sistemático en configuración de productos/clientes en Odoo.

**Acción:**
1. Escalar a contador externo (para Manuel: Jorge Hernández, MYH Contadores).
2. Validar que cada factura sin IVA tenga respaldo documental: resolución exonerativa DGT, nota de exención del cliente, o naturaleza exportable del servicio.
3. Si Hacienda audita, cada factura sin IVA requiere justificación individual.

Ver `fiscal-cr.md` para tarifas y exenciones vigentes.

---

## H5 — Borradores olvidados 🟡

**Criterio:** `state='draft'`.

**Causa probable:** Factura creada pero nunca posteada. Si la fecha es antigua (>30 días), probablemente abandono operativo.

**Acción:** Postear si es válida, cancelar si no.

---

## H6 — Canceladas con número asignado 🟡

**Criterio:** `state='cancel'` y `name` no es placeholder (tiene consecutivo real como "INV/2026/00042").

**Causa probable:** Cancelación post-posting. En Costa Rica esto **rompe el consecutivo fiscal** si no se emitió nota de crédito.

**Acción:**
1. Verificar que exista nota de crédito asociada.
2. Si no, generar nota de crédito que compense.
3. Documentar en libro de ventas la razón de cancelación.

---

## H7 — Facturas en `in_payment` sin conciliar 🔴

**Criterio:** `state='posted'`, `payment_state='in_payment'`, `amount_residual > 0`.

**Significado en Odoo:** Existe un `account.payment` vinculado pero no está conciliado contra un extracto bancario. Odoo considera que el pago fue registrado pero no confirmado por el banco.

**Causa probable:**
1. Conciliación bancaria desatendida (el caso más común).
2. Pagos registrados manualmente sin respaldo del banco (riesgo fiscal — crea ingresos fantasma si no hay depósito real).
3. Diferencias entre `account.payment.date` y la fecha del movimiento bancario real.

**Acción:**
1. **Crítico:** correr conciliación bancaria con Promerica USD y Promerica CRC hasta el último extracto.
2. Cruzar cada pago en `in_payment` contra movimiento bancario real.
3. Si hay pagos sin respaldo bancario → reversar payment y reclasificar.

Consulta de verificación:
```python
# Listar payments vinculados a una factura en in_payment
account.move.line.search_read(
    [('move_id','=',invoice_id)],
    ['id','account_id','reconciled','matched_debit_ids','matched_credit_ids']
)
```

---

## H8 — Partner duplicado 🟠

**Criterio:** Clientes con nombre normalizado idéntico pero distinto `partner_id`.

**Normalización aplicada:** mayúsculas, sin puntos/comas, "S.A."→"SA", "SOCIEDAD ANONIMA"→"SA", "SOCIEDAD DE RESPONSABILIDAD LIMITADA"→"SRL".

**Causa probable:** Captura descuidada en CRM, importaciones múltiples, sincronización fallida.

**Impacto:** Aging fragmentado (el cliente parece tener menos deuda de la real), campañas de marketing duplicadas, estados de cuenta incorrectos.

**Acción:** Fusionar partners en Odoo usando la herramienta **Contactos > Fusionar contactos**. **No fusionar automáticamente desde este skill** — la fusión impacta CRM, ventas, facturas y contabilidad.

---

## H9 — Saldo pendiente > total 🟠

**Criterio:** `amount_residual > amount_total + 0.01`.

**Causa probable:** Sobrepago registrado erróneamente, nota de crédito mal vinculada, corrupción de asiento contable.

**Acción:** Revisar asiento contable (`account.move.line`) para identificar desbalance. Puede requerir ajuste manual del contador.

---

## H10 — Posted sin referencia a sale.order 🟡

**Criterio:** `state='posted'`, `move_type='out_invoice'`, `invoice_origin` vacío.

**Causa probable:** Factura creada directamente sin cotización previa. Rompe la trazabilidad comercial CRM → cotización → factura.

**Acción:** No es corregible retroactivamente en la mayoría de casos. Usar como métrica de proceso para reforzar flujo comercial.

---

## H11 — Vencimiento anterior a emisión 🔴

**Criterio:** `invoice_date_due < invoice_date`.

**Causa probable:** Error de captura manual. Contablemente absurdo (factura nacida ya vencida).

**Acción:** Corregir `invoice_date_due` caso por caso. Si el término de pago estándar es "contado", el vencimiento debería igualar la fecha de emisión.

---

## H12 — Clientes con aging profundo (>90 días) 🟠

**Criterio:** CxC con `Días atraso > 90`.

**Causa probable:** Cobranza deficiente, cliente en dificultad financiera, o producto/servicio disputado.

**Acción:**
1. Clasificar por cliente.
2. Gestión activa: contacto, acuerdo de pago, o aplicación de intereses moratorios.
3. Evaluar provisión por incobrabilidad (SUGEF 1-05 aplica a entidades reguladas; para Colé/Kermatec como empresa privada no regulada, criterio prudencial propio).

---

## H13 — Moneda distinta a CRC/USD 🟡

**Criterio:** `currency_id.name` no es CRC ni USD.

**Causa probable:** Captura accidental en EUR, GBP u otra moneda poco común para el negocio.

**Acción:** Verificar si la factura tiene justificación (cliente extranjero que paga en su moneda). Si es error, reemitir en CRC o USD.

---

## H14 — Fecha de emisión futura 🟡

**Criterio:** `invoice_date > today`.

**Causa probable:** Error de captura (año siguiente, mes siguiente). Algunas jurisdicciones permiten facturación anticipada con justificación contractual.

**Acción:** Validar caso por caso. En Costa Rica, Hacienda espera que `invoice_date = fecha real de emisión electrónica`.

---

## H15 — Facturas posted con total ≤ 1 🟠

**Criterio:** `state='posted'`, `move_type='out_invoice'`, `0 < amount_total ≤ 1`.

**Causa probable:** Error de captura (punto decimal mal colocado, cantidad=0 con precio unitario=1, factura de prueba que escapó).

**Acción:** Revisar individualmente. Si es error, anular con nota de crédito. Si es facturación simbólica legítima (ajuste contable, muestra), documentar en memo.

---

## Roadmap — Hallazgos futuros

Candidatos a incorporar en v2:

- **H16** — Facturas con línea de producto genérica (sin `product_id`). Indica escritura libre vs catálogo.
- **H17** — Diferencia entre `amount_total` y suma de `line_ids.price_subtotal * (1+tax)` (integridad de líneas).
- **H18** — Facturas a un mismo cliente con misma fecha, mismo monto, mismo producto (duplicación accidental).
- **H19** — Secuencia rota en `name` (saltos en consecutivo de numeración interna).
- **H20** — Ratio factura/cotización < 1 (facturación parcial respecto a lo cotizado — OK si es por entregas, sospechoso si debería ser total).
