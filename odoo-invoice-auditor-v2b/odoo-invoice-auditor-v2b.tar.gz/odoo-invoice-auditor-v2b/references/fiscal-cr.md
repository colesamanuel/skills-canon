# Validación Fiscal Costa Rica — Facturación Electrónica

Referencia para el nivel C (integridad fiscal) del auditor. **Esta guía es orientativa, no sustituye criterio de contador público autorizado.**

Para Colé S.A. y Kermatec Dosimetric S.A., la referencia operativa es el contador externo Jorge Hernández (MYH Contadores).

---

## 1. Tarifas de IVA vigentes (Ley 9635, vigente desde 2019)

| Código | Tarifa | Aplicación típica |
|---|---:|---|
| General | 13% | Servicios y bienes por defecto |
| Reducida 1 | 4% | Servicios de salud privados, boletos aéreos nacionales |
| Reducida 2 | 2% | Medicamentos, insumos agropecuarios |
| Reducida 3 | 1% | Canasta básica, productos veterinarios específicos |
| Exento | 0% (sin crédito) | Educación privada, alquiler vivienda uso habitacional, servicios financieros |
| Exonerado | 0% (con autorización) | Sector público con exoneración, instituciones específicas |
| No sujeto | — | Operaciones fuera del ámbito de IVA |

**Relevancia para Kermatec/Colé:**

- Equipos de protección radiológica vendidos a **hospitales públicos (CCSS)**: cliente puede presentar **autorización de compra exenta (exoneración)** — la factura lleva IVA 0 pero con referencia a la resolución DGT correspondiente.
- **Universidades estatales (UCR, UNA, TEC, UNED)**: régimen de exoneración.
- **Servicios de dosimetría personal**: **no necesariamente exentos**. Validar caso por caso. La prestación de un servicio técnico especializado suele aplicar 13% salvo exoneración específica del cliente.
- **Capacitación privada**: IVA 13% (la exención aplica solo a educación formal regulada por MEP/CONESUP).
- **Exportación** (ej: servicio a KDM Panamá): tarifa 0% con derecho a crédito.

---

## 2. Clave numérica Hacienda (50 dígitos)

Estructura oficial según Resolución DGT-R-48-2016:

```
C CC YYMMDD CCCCCCCCCCCC TT S NNNNNNNNNN SSSSSSSS
│  │   │         │          │  │      │        │
│  │   │         │          │  │      │        └─ Código de seguridad (8 dígitos)
│  │   │         │          │  │      └─ Consecutivo del comprobante (10 dígitos)
│  │   │         │          │  └─ Situación del comprobante (1 dígito: 1-normal, 2-contingencia, 3-sin internet)
│  │   │         │          └─ Tipo de comprobante (2 dígitos: 01-FE, 02-ND, 03-NC, 04-TE, 08-FEC, 09-FEE)
│  │   │         └─ Cédula del emisor (12 dígitos, con ceros a la izquierda)
│  │   └─ Fecha de emisión (AAMMDD)
│  └─ País (506 Costa Rica)
└─ Código país (sin uso)
```

**Validaciones del auditor (nivel C):**
1. Los 50 dígitos son solo numéricos.
2. Cédula corresponde al emisor (Colé: 3101392010, Kermatec: 3101857015).
3. Fecha embebida coincide con `invoice_date` de Odoo.
4. Tipo de comprobante coincide con `move_type` (01=FE para `out_invoice`, 03=NC para `out_refund`).
5. Consecutivo no se repite.

**Localización Odoo para CR:** los módulos oficiales de localización costarricense (l10n_cr) almacenan la clave en campos custom como `l10n_cr_clave`, `l10n_cr_consecutivo`. Si los módulos están instalados, leer esos campos. Si no, este nivel de validación no aplica en este tenant y debe ejecutarse contra el sistema externo que emite las claves (comúnmente Tiquetes de Costa Rica API, o motor propio).

---

## 3. Consecutivo interno (20 dígitos)

Estructura embebida en la clave, también disponible como campo independiente:

```
CCC CCCCC TT NNNNNNNNNN
│    │    │       │
│    │    │       └─ Consecutivo secuencial (10 dígitos)
│    │    └─ Tipo comprobante (2 dígitos)
│    └─ Terminal / punto de venta (5 dígitos)
└─ Sucursal (3 dígitos)
```

**Validación crítica:** el consecutivo por sucursal + terminal + tipo debe ser **estrictamente secuencial sin saltos**. Cualquier salto indica:
- Factura cancelada sin nota de crédito (hallazgo H6).
- Fallo del motor de facturación.
- Manipulación manual.

**Método de detección:**
```python
# Pseudocódigo
for tipo in ['out_invoice', 'out_refund']:
    consecutivos = sorted([int(f.consecutivo[-10:]) for f in facturas_del_tipo])
    saltos = [(c1, c2) for c1, c2 in zip(consecutivos, consecutivos[1:]) if c2 - c1 > 1]
```

---

## 4. Libro de ventas

Hacienda exige mantener libro de ventas con:
- Fecha de emisión.
- Nombre del receptor.
- Cédula del receptor.
- Número de comprobante.
- Total gravado (por tarifa).
- Total exento.
- Total exonerado.
- Impuesto cobrado.

**Validación del auditor:** la suma de `amount_untaxed` por tarifa debe coincidir con los totales reportados en las declaraciones D-104 (IVA mensual). Este cruce requiere data externa y queda fuera del alcance automatizable de este skill.

---

## 5. Exenciones por tipo de receptor

| Tipo de receptor | Tratamiento | Campo Odoo a validar |
|---|---|---|
| Consumidor final (sin cédula) | IVA aplicable según producto | `partner_id` vacío o genérico |
| Empresa privada | IVA aplicable según producto | `partner_id.vat` con formato 3-101-xxxxxx |
| CCSS y sus subentidades | Requiere autorización de compra exenta | `partner_id` vinculado a CCSS (ID 152 para HCG, 131 para Dpto. Protección Radiológica) |
| Universidades estatales | Exoneración por ley | `partner_id` UNA/UCR/TEC |
| Sector público ejecutivo | Requiere autorización específica | Verificar documento adjunto |
| Exportación | Tarifa 0% | `partner_id.country_id != Costa Rica` |

El auditor puede marcar (🟠) facturas a receptores públicos sin IVA que no tengan **referencia explícita a autorización exenta** en el campo `ref` o en archivo adjunto. Esto no significa que la factura esté mal — significa que requiere evidencia adicional para defenderse en auditoría.

---

## 6. Roadmap nivel C

Checks a implementar en `audit_invoices.py` cuando `--level ABC`:

1. **C1** — Validar que toda factura a cliente CCSS/universidad con IVA=0 tenga campo `ref` no vacío (referencia a autorización).
2. **C2** — Listar consecutivos y detectar saltos.
3. **C3** — Cruzar cédula del receptor contra formato válido (3-XXX-XXXXXX para jurídicas, 9 dígitos para físicas, 1-XXXX-XXXX para DIMEX).
4. **C4** — Agrupar facturas por tarifa aplicada y detectar productos con tarifa inconsistente (mismo producto facturado a veces con 13% y a veces con 0%).
5. **C5** — Si el tenant tiene módulo l10n_cr instalado, validar estructura de clave numérica.

---

## 7. Cuándo escalar a contador

Este skill **no reemplaza** el criterio del contador. Escalar a MYH Contadores cuando:

- H4 (IVA=0 masivo) supera el 20% del total facturado.
- Hay saltos en consecutivo fiscal sin nota de crédito documentada.
- Hallazgos de aritmética inconsistente (H3) afectan facturas posted.
- Cierre mensual o trimestral pendiente.
- Auditoría Hacienda notificada.

---

## Referencias normativas

- **Ley 9635** (Fortalecimiento de las Finanzas Públicas) — marco del IVA vigente.
- **Reglamento de la Ley del IVA** — Decreto Ejecutivo 41779-H.
- **Resolución DGT-R-48-2016** — Facturación electrónica, estructura de clave y comprobantes.
- **Resolución DGT-R-033-2019** — Actualización de tarifas y códigos.
- **Resolución DGT-R-25-2021** — Criterios de exoneración.

Verificar vigencia en portal de Hacienda (`www.hacienda.go.cr`) antes de aplicar — las resoluciones cambian.
